//
//  ViewController.swift
//  Swift Basics
//
//  Created by Chuyang Lin on 6/15/18.
//  Copyright © 2018 Tech Innovator. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Heading: UILabel!
    @IBOutlet weak var Sample1: UILabel!
    @IBOutlet weak var Sample2: UILabel!
    @IBOutlet weak var HeartRate: UILabel!
    @IBOutlet weak var Deposits: UILabel!
    @IBOutlet weak var Acceleration: UILabel!
    @IBOutlet weak var Mass: UILabel!
    @IBOutlet weak var Distance: UILabel!
    @IBOutlet weak var Lost: UILabel!
    @IBOutlet weak var Expensive: UILabel!
    @IBOutlet weak var Choice: UILabel!
    @IBOutlet weak var Integral: UILabel!
    @IBOutlet weak var Greeting: UILabel!
    @IBOutlet weak var Name: UILabel!
    
    @IBOutlet weak var Cmp1: UILabel!
    @IBOutlet weak var Cmp2: UILabel!
    @IBOutlet weak var Cmp3: UILabel!
    @IBOutlet weak var Force: UILabel!
    @IBOutlet weak var dis: UILabel!
    @IBOutlet weak var LostAndExp: UILabel!
    @IBOutlet weak var CheckChoice: UILabel!
    @IBOutlet weak var CheckIntergral: UILabel!
    
    
    var sample1: UInt8 = 0x3A
    var sample2: UInt8 = 58
    var heartRate: Int = 85
    var deposits:Double = 135002796
    var acceleration:Float=9.800
    var mass :Float=14.6
    var distance :Double=129.763001
    var lost: Bool=true
    var expensive :Bool=true
    var choice:Int=2
    let integral : Character = "\u{222B}"
    let greeting: String="Hello"
    var name: String="Karen"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func DisplayMessage(_ sender: Any) {
        Sample1.text = "sample1 is \(sample1)"
        Sample2.text = "sample2 is \(sample2)"
        HeartRate.text = "heatRate is \(heartRate)"
        Deposits.text = "deposits is \(deposits)"
        Acceleration.text = "acceleration is \(acceleration)"
        Mass.text = "mass is \(mass)"
        Distance.text = "distance is \(distance)"
        Lost.text = "lost is \(lost)"
        Expensive.text = "expensive is \(expensive)"
        Choice.text = "choice is \(choice)"
        Integral.text = "integral is \(integral)"
        Greeting.text = "greeting is \(greeting)"
        Name.text = "name is \(name)"
        
        if sample1 == sample2 {
            Cmp1.text = "The samples are equal"
        }else {
            Cmp1.text = "The samples are not equal"
        }
        
        if (heartRate >= 40) && (heartRate <= 80) {
            Cmp2.text = "Heart rate is normal."
        } else{
            Cmp2.text = "Heart rate is not normal."
        }
        
        if (deposits >= 100000000) {
            Cmp3.text = "You are exceedingly wealthy."
        }else{
            Cmp3.text = "Sorry you are so poor."
        }
        
        let force = mass*acceleration
        
        Force.text = "force = \(force)"
        dis.text = "\(distance) is the distance."
        
        if lost && expensive {
            LostAndExp.text = "I am really sorry! I will get the manager."
        }else if lost && !expensive {
            LostAndExp.text = "Here is coupon for 10% off."
        }
        
        switch choice {
        case 1 : CheckChoice.text = "You chose 1."
        case 2 : CheckChoice.text = "You chose 2."
        case 3 : CheckChoice.text = "You chose 3."
            
        default: CheckChoice.text = "You made an unknown choice."
        }
        
        CheckIntergral.text = "\(integral) is an integral."
        
        for i in 5 ... 10{
            print("i = \(i)")
        }
        
        var age: Int=0
        while age < 6 {
            print("age = \(age)")
            age+=1
        }
        
        print(greeting,name)
    }
    

}

